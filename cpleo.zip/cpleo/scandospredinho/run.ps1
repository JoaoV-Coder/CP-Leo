param(
    [string]$google.com,
    [int]$22
)

function Test-Port {
    param(
        [string]$host,
        [int]$port
    )

    try {
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $tcpClient.Connect($host, $port)
        $tcpClient.Close()
        return $true
    } catch {
        return $false
    }
}

if (Test-Port -host $hostName -port $port) {
    Write-Output "A porta $port está aberta em $hostName."
} else {
    Write-Output "A porta $port está fechada em $hostName."
}
